(() => {
  const $ = (id) => document.getElementById(id);

  const socketState = $('socketState');
  const modeState = $('modeState');
  const lastCommandText = $('lastCommandText');
  const connectionText = $('connectionText');
  const connectionDot = $('connectionDot');
  const peerText = $('peerText');
  const peerDot = $('peerDot');
  const laptopLog = $('laptopLog');
  const toastWrap = $('toastWrap');
  const connectBtn = $('connectBtn');
  const manualResetBtn = $('manualResetBtn');

  let socket = null;
  let connected = false;
  let stepIndex = -1;
  const steps = [];

  function collectSteps() {
    steps.length = 0;
    document.querySelectorAll('.step-card').forEach((el) => steps.push(el));
  }

  function toast(message, type = 'ok') {
    const el = document.createElement('div');
    el.className = `toast ${type === 'error' ? 'error' : type === 'warn' ? 'warn' : ''}`;
    el.textContent = message;
    toastWrap.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(8px)';
      setTimeout(() => el.remove(), 220);
    }, 2600);
  }

  function addLog(message) {
    const item = document.createElement('div');
    item.className = 'log-item';
    item.innerHTML = message;
    laptopLog.prepend(item);
  }

  function setConnection(text, cls = 'idle') {
    connectionText.textContent = text;
    socketState.textContent = text;
    connectionDot.className = `status-dot ${cls}`;
  }

  function setPeer(text, cls = 'idle') {
    peerText.textContent = text;
    peerDot.className = `status-dot ${cls}`;
  }

  function setMode(mode) {
    modeState.textContent = `mode: ${mode || '-'}`;
  }

  function setLastCommand(command) {
    lastCommandText.textContent = `command: ${command || '-'}`;
  }

  function ensureSocket() {
    if (socket) return socket;

    socket = io({
      autoConnect: false,
      transports: ['websocket', 'polling']
    });

    socket.on('connect', () => {
      connected = true;
      setConnection('terhubung', 'ok');
      connectBtn.textContent = 'Connected';
      connectBtn.disabled = true;
      socket.emit('register-device', {
        role: 'laptop',
        mode: 'local',
        clientName: 'laptop-receiver'
      });
      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Laptop receiver aktif.`);
      toast('Laptop siap menerima command.', 'ok');
    });

    socket.on('disconnect', () => {
      connected = false;
      setConnection('belum terhubung', 'idle');
      connectBtn.textContent = 'Connect / Ready';
      connectBtn.disabled = false;
      toast('Koneksi laptop putus.', 'warn');
    });

    socket.on('status-update', (payload) => {
      if (payload.role === 'laptop') {
        if (payload.status === 'terhubung') setConnection('terhubung', 'ok');
        if (payload.status === 'putus') setConnection('putus', 'bad');
      }
      if (payload.mode) setMode(payload.mode);
    });

    socket.on('peer-status', (payload) => {
      setPeer(`${payload.peer}: ${payload.status}`, payload.status === 'terhubung' ? 'ok' : payload.status === 'putus' ? 'bad' : 'idle');
      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Peer ${payload.peer} ${payload.status}`);
    });

    socket.on('command', (payload) => {
      const command = payload.command || '-';
      setLastCommand(command);
      setMode(payload.mode || 'unknown');
      setPeer(`phone: ${payload.source || 'phone'}`, 'ok');

      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Menerima <strong>${command}</strong> <span class="muted">${payload.transcript || ''}</span>`);
      toast(`Command diterima: ${command}`, 'ok');
      applyCommand(command);
    });

    socket.on('error-message', (payload) => {
      toast(payload.message || 'Error terjadi.', 'error');
    });

    return socket;
  }

  function connectSocket() {
    ensureSocket();
    if (socket.connected) return;
    setConnection('sedang mencari perangkat', 'idle');
    connectBtn.textContent = 'Connecting...';
    connectBtn.disabled = true;
    socket.connect();
  }

  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function scrollDown() {
    window.scrollBy({ top: Math.max(420, window.innerHeight * 0.7), behavior: 'smooth' });
  }

  function scrollUp() {
    window.scrollBy({ top: -Math.max(420, window.innerHeight * 0.7), behavior: 'smooth' });
  }

  function nextAction() {
    collectSteps();
    if (!steps.length) return;

    stepIndex = (stepIndex + 1) % steps.length;
    const el = steps[stepIndex];
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.focus({ preventScroll: true });
    el.style.transform = 'scale(1.01)';
    setTimeout(() => {
      el.style.transform = '';
    }, 180);
  }

  function applyCommand(command) {
    switch (command) {
      case 'down':
        scrollDown();
        break;
      case 'up':
        scrollUp();
        break;
      case 'next':
        nextAction();
        break;
      case 'reset':
        stepIndex = -1;
        scrollToTop();
        break;
      default:
        break;
    }
  }

  connectBtn.addEventListener('click', connectSocket);
  manualResetBtn.addEventListener('click', () => {
    setLastCommand('reset');
    applyCommand('reset');
    toast('Tampilan direset.', 'ok');
  });

  collectSteps();
  setConnection('belum terhubung', 'idle');
  setPeer('-', 'idle');
  setMode('-');

  window.addEventListener('beforeunload', () => {
    try {
      if (socket) socket.disconnect();
    } catch (e) {}
  });

  connectSocket();
})();
