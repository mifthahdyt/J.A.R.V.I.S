(() => {
  const $ = (id) => document.getElementById(id);

  const socketState = $('socketState');
  const modeState = $('modeState');
  const micState = $('micState');
  const connectionText = $('connectionText');
  const connectionDot = $('connectionDot');
  const speechText = $('speechText');
  const speechDot = $('speechDot');
  const lastCommandText = $('lastCommandText');
  const commandDot = $('commandDot');
  const transcriptBox = $('transcriptBox');
  const phoneLog = $('phoneLog');
  const toastWrap = $('toastWrap');

  const connectBtn = $('connectBtn');
  const startBtn = $('startBtn');
  const stopBtn = $('stopBtn');
  const modeBluetooth = $('modeBluetooth');
  const modeCable = $('modeCable');
  const bluetoothInfo = $('bluetoothInfo');
  const cableInfo = $('cableInfo');

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let socket = null;
  let connected = false;
  let listening = false;
  let selectedMode = 'bluetooth';
  let lastSentPhrase = '';
  let lastSentCommand = '';
  let reconnectTimer = null;

  function setSocketState(text, cls = 'idle') {
    socketState.textContent = text;
    connectionText.textContent = text;
    connectionDot.className = `status-dot ${cls}`;
  }

  function setSpeechState(text, cls = 'idle') {
    micState.textContent = `mic: ${text}`;
    speechText.textContent = text;
    speechDot.className = `status-dot ${cls}`;
  }

  function setCommandState(text, cls = 'idle') {
    lastCommandText.textContent = text;
    commandDot.className = `status-dot ${cls}`;
  }

  function setMode(mode) {
    selectedMode = mode;
    modeState.textContent = `mode: ${mode}`;
    modeBluetooth.classList.toggle('active', mode === 'bluetooth');
    modeCable.classList.toggle('active', mode === 'kabel');

    if (mode === 'bluetooth') {
      const supported = !!navigator.bluetooth;
      bluetoothInfo.textContent = supported
        ? 'Browser ini mendukung Web Bluetooth secara terbatas. Project tetap memakai server lokal agar command stabil, lalu menampilkan status mode Bluetooth.'
        : 'Browser ini tidak mendukung Web Bluetooth. Project otomatis memakai fallback lokal dan menampilkan pesan jelas agar tetap bisa dicoba.';
      toast(supported ? 'Bluetooth mode dipilih. Dukungan browser terdeteksi.' : 'Bluetooth tidak didukung di browser ini. Fallback lokal aktif.', supported ? 'ok' : 'warn');
    } else {
      cableInfo.textContent = 'Mode kabel dipilih. Jalur yang dipakai tetap lokal melalui server Node di laptop, cocok untuk koneksi sederhana dan stabil.';
      toast('Mode kabel dipilih.', 'ok');
    }

    if (socket && connected) {
      socket.emit('select-mode', { mode: selectedMode });
    }
  }

  function toast(message, type = 'ok') {
    const el = document.createElement('div');
    el.className = `toast ${type === 'error' ? 'error' : type === 'warn' ? 'warn' : ''}`;
    el.textContent = message;
    toastWrap.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(8px)';
      setTimeout(() => el.remove(), 220);
    }, 2400);
  }

  function addLog(message) {
    const item = document.createElement('div');
    item.className = 'log-item';
    item.innerHTML = message;
    phoneLog.prepend(item);
  }

  function updateConnection(online, reason = '') {
    connected = online;
    if (online) {
      setSocketState('terhubung', 'ok');
      toast('HP terhubung ke server lokal.', 'ok');
      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Connected. ${reason ? `<span class="muted">${reason}</span>` : ''}`);
      connectBtn.textContent = 'Connected';
      connectBtn.disabled = true;
      connectBtn.classList.add('blink');
      setTimeout(() => connectBtn.classList.remove('blink'), 800);
    } else {
      setSocketState('belum terhubung', 'idle');
      connectBtn.textContent = 'Connect';
      connectBtn.disabled = false;
      if (reason) toast(reason, 'warn');
    }
  }

  function setupSocket() {
    if (socket) return socket;

    socket = io({
      autoConnect: false,
      transports: ['websocket', 'polling']
    });

    socket.on('connect', () => {
      updateConnection(true, 'Socket.IO aktif.');
      socket.emit('register-device', {
        role: 'phone',
        mode: selectedMode,
        clientName: 'phone-controller'
      });
      socket.emit('select-mode', { mode: selectedMode });
    });

    socket.on('disconnect', () => {
      updateConnection(false, 'Koneksi socket putus.');
      setSpeechState('idle', 'idle');
    });

    socket.on('registered', (payload) => {
      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Registered as <strong>${payload.role}</strong>`);
    });

    socket.on('mode-ack', (payload) => {
      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Mode tersimpan: <strong>${payload.mode}</strong>`);
    });

    socket.on('command-delivered', (payload) => {
      setCommandState(payload.command, 'ok');
      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Command terkirim: <strong>${payload.command}</strong>`);
      toast(`Command ${payload.command} terkirim.`, 'ok');
    });

    socket.on('command-ignored', (payload) => {
      toast(payload.reason || 'Command diabaikan.', 'warn');
    });

    socket.on('error-message', (payload) => {
      toast(payload.message || 'Terjadi error.', 'error');
    });

    socket.on('peer-status', (payload) => {
      addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Peer ${payload.peer} ${payload.status}`);
    });

    return socket;
  }

  function connectSocket() {
    setupSocket();
    if (socket.connected) return;
    setSocketState('sedang mencari perangkat', 'idle');
    connectBtn.disabled = true;
    connectBtn.textContent = 'Connecting...';
    socket.connect();

    if (reconnectTimer) clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => {
      if (!socket.connected) {
        updateConnection(false, 'Gagal konek. Pastikan server Node di laptop sudah berjalan.');
      }
    }, 5000);
  }

  function normalizeCommand(transcript) {
    const text = transcript.toLowerCase();

    if (/\breset\b/.test(text)) return 'reset';
    if (/\bnext\b/.test(text)) return 'next';
    if (/\bdown\b/.test(text)) return 'down';
    if (/\bup\b/.test(text)) return 'up';
    return '';
  }

  function sendCommand(command, transcript) {
    if (!socket || !socket.connected) {
      toast('Belum terhubung ke server.', 'warn');
      return;
    }

    const key = `${command}::${transcript}`;
    if (key === `${lastSentCommand}::${lastSentPhrase}`) return;

    lastSentCommand = command;
    lastSentPhrase = transcript;

    socket.emit('voice-command', {
      command,
      transcript,
      mode: selectedMode
    });

    setCommandState(command, 'ok');
  }

  function initRecognition() {
    if (!SpeechRecognition) {
      setSpeechState('speech recognition tidak didukung', 'bad');
      transcriptBox.textContent = 'Browser ini tidak mendukung Web Speech API SpeechRecognition.';
      startBtn.disabled = true;
      stopBtn.disabled = true;
      toast('SpeechRecognition tidak didukung di browser ini.', 'error');
      return null;
    }

    recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      listening = true;
      setSpeechState('mendengarkan', 'ok');
      transcriptBox.textContent = 'Mendengarkan... ucapkan down / up / next / reset.';
      startBtn.textContent = 'Listening';
      toast('Mic aktif.', 'ok');
    };

    recognition.onend = () => {
      listening = false;
      setSpeechState('berhenti', 'idle');
      startBtn.textContent = 'Start Listening';
    };

    recognition.onerror = (event) => {
      listening = false;
      setSpeechState(`error: ${event.error}`, 'bad');
      toast(`Speech error: ${event.error}`, 'error');
    };

    recognition.onresult = (event) => {
      let interim = '';
      let finalText = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const text = res[0].transcript.trim();
        if (res.isFinal) {
          finalText += `${text} `;
        } else {
          interim += `${text} `;
        }
      }

      const shown = `${finalText}${interim}`.trim();
      if (shown) transcriptBox.textContent = shown;

      if (finalText) {
        const command = normalizeCommand(finalText);
        if (command) {
          addLog(`<strong>${new Date().toLocaleTimeString()}</strong> — Terdeteksi: <strong>${command}</strong> <span class="muted">(${finalText.trim()})</span>`);
          sendCommand(command, finalText.trim());
        }
      }
    };

    return recognition;
  }

  function startListening() {
    if (!recognition) initRecognition();
    if (!recognition) return;

    try {
      recognition.start();
    } catch (err) {
      toast('Mic sudah aktif atau browser menolak start ulang.', 'warn');
    }
  }

  function stopListening() {
    if (!recognition) return;
    try {
      recognition.stop();
    } catch (err) {}
  }

  modeBluetooth.addEventListener('click', () => setMode('bluetooth'));
  modeCable.addEventListener('click', () => setMode('kabel'));
  connectBtn.addEventListener('click', connectSocket);
  startBtn.addEventListener('click', startListening);
  stopBtn.addEventListener('click', stopListening);

  setMode('bluetooth');
  initRecognition();

  if (window.Notification && Notification.permission === 'default') {
    Notification.requestPermission().catch(() => {});
  }

  window.addEventListener('beforeunload', () => {
    try {
      if (recognition) recognition.stop();
      if (socket) socket.disconnect();
    } catch (e) {}
  });
})();
